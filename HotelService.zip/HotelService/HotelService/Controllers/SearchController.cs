﻿using HotelService.DAL;
using HotelService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace HotelService.Controllers
{
    public class SearchController : ApiController
    {
        HotelDBManager dbManager = new HotelDBManager();

        // POST api/Search/SearchHotel/cityId,priceOrder
        [AcceptVerbs("GET", "POST")]
        public List<HotelEntity> SearchHotel(string apiKey, string cityId, string priceOrder)
        {
            return dbManager.SearchHotelByCityId(apiKey, cityId, priceOrder);
        }

        // POST api/Search/SearchHotel/cityId
        [AcceptVerbs("GET", "POST")]
        public List<HotelEntity> SearchHotel(string apiKey, string cityId)
        {
            return dbManager.SearchHotelByCityId(apiKey, cityId, string.Empty);
        }

    }
}

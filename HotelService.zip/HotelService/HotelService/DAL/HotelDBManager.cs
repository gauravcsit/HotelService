﻿using HotelService.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace HotelService.DAL
{
    public class HotelDBManager
    {
        // Hotel data in .csv format 
        public static string hoteldb = ConfigurationManager.AppSettings["hoteldb"];

        // Api Key data in .csv format 
        public static string apiKeydb = ConfigurationManager.AppSettings["apiKeydb"];

        // Global Rate Limit 
        public static string rateLimitGlobal = ConfigurationManager.AppSettings["rateLimitGlobal"];

        /// <summary>
        /// Return Global rate from config
        /// </summary>
        /// <returns></returns>
        private int GetGlobalRateLimitInSeconds()
        {
            int rateLimitInSeconds;
            if (!int.TryParse(rateLimitGlobal, out rateLimitInSeconds))
            {
                rateLimitInSeconds = 10;// Default rateLimit
            }

            return rateLimitInSeconds;
        }

        /// <summary>
        /// Search Hotels By matching City, priceOrder is optional (asc or desc) 
        /// </summary>
        /// <param name="cityId"></param>
        /// <param name="priceOrder"></param>
        /// <returns></returns>
        public List<HotelEntity> SearchHotelByCityId(string apikey, string cityId, string priceOrder)
        {
            if (!AccessByApiKey(apikey))
            {
                return null;
            }

            List<HotelEntity> hotelList = new List<HotelEntity>();

            string line;
            FileStream hotelFile = new FileStream(hoteldb, FileMode.Open);
            StreamReader sr = new StreamReader(hotelFile);

            HotelEntity hotelEntity;

            sr.ReadLine();// Discard header line

            // read data in line by line
            while ((line = sr.ReadLine()) != null)
            {
                hotelEntity = new HotelEntity();

                // split the comma saparated values and map with hotel Entity
                string[] row = line.Split(',');

                hotelEntity.City = row[0];
                hotelEntity.HotelId = row[1];
                hotelEntity.Room = row[2];
                hotelEntity.Price = Convert.ToDouble(row[3]);

                //Add Hotel Entity into Hotel List
                hotelList.Add(hotelEntity);
            }

            sr.Close();

            // Filter the holel list by city
            List<HotelEntity> result = hotelList.Where(o => o.City.ToLower().Contains(cityId.ToLower())).ToList();

            //  Order ofthe search hotel list 
            if (priceOrder != string.Empty && priceOrder.Trim().ToLower() == "asc")
            {
                result = result.OrderBy(o => o.Price).ToList();
            }
            else if (priceOrder != string.Empty && priceOrder.Trim().ToLower() == "desc")
            {
                result = result.OrderByDescending(o => o.Price).ToList();
            }
            else
            {
                result = result.ToList();
            }

            return result;
        }

        /// <summary>
        /// Check Api Key is valid with access or not
        /// </summary>
        /// <param name="apiKey"></param>
        /// <returns></returns>
        private bool AccessByApiKey(string apiKey)
        {
            List<ApiKeyEntity> ApiKeyList = new List<ApiKeyEntity>();

            XmlSerializer serializer = new XmlSerializer(typeof(List<ApiKeyEntity>));
            StreamReader reader = new StreamReader(apiKeydb);

            // Map ApiKeyList with ApiKeys stored in Xml file 
            ApiKeyList = (List<ApiKeyEntity>)serializer.Deserialize(reader);
            reader.Close();

            var record = ApiKeyList.Where(o => o.ApiKey == apiKey).FirstOrDefault();
            if (record == null)
            {
                return false;   // Not Allow as ApiKey not found
            }
            else
            {
                // API Key is Valid checking access availablity

                bool result = false;
                int rateInSec;

                if (record.Rate != null)
                {
                    rateInSec = (int)record.Rate;
                }
                else
                {
                    rateInSec = GetGlobalRateLimitInSeconds();
                }

                DateTime now = DateTime.Now;

                if (record.NextAccess <= now)
                {
                    // Allow and update NextAccess and LastAccess, make Active                       
                    record.LastAccess = now;
                    record.NextAccess = now.AddSeconds(rateInSec);
                    record.Status = "ACTIVE";
                    result = true; // Allow
                }
                else
                {
                    if (record.Status.Trim().ToUpper() == "ACTIVE")
                    {
                        // Not Allow and make InActive and update NextAccess to 5 min from this
                        record.LastAccess = now;
                        record.NextAccess = now.AddMinutes(5);// InActive for 5 mins
                        record.Status = "INACTIVE";
                        result = false; // Not Allow
                    }
                    else
                    {
                        // Ignore Request as API key already INACTIVE
                        result = false; // Not Allow
                    }
                }

                //  Saving the ApiKey List into XML file by Serializing ApiKeyList 
                using (FileStream fs = new FileStream(apiKeydb, FileMode.Create))
                {
                    serializer.Serialize(fs, ApiKeyList);
                }

                return result;
            }
        }
    }
}
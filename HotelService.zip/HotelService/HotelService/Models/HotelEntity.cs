﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HotelService.Models
{
    public class HotelEntity
    {
        private string city;
        private string hotelId;
        private string room;
        private double price;

        public string City
        {
            get { return city; }
            set { city = value; }
        }

        public string HotelId
        {
            get { return hotelId; }
            set { hotelId = value; }
        }

        public string Room
        {
            get { return room; }
            set { room = value; }
        }

        public double Price
        {
            get { return price; }
            set { price = value; }
        }

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HotelService.Models
{
    /// <summary>
    /// Class used to Serialize API Key list to store XML file
    /// </summary>
    [Serializable]
    public class ApiKeyEntity
    {
        private string apiKey;
        private int id;
        private int? rate;
        private DateTime lastAccess;
        private DateTime nextAccess;
        private string status;

        /// <summary>
        /// API Key 
        /// </summary>
        public string ApiKey
        {
            get { return apiKey; }
            set { apiKey = value; }
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        /// <summary>
        /// Rate Limit for API key.
        /// </summary>
        public int? Rate
        {
            get { return rate; }
            set { rate = value; }
        }

        public DateTime LastAccess
        {
            get { return lastAccess; }
            set { lastAccess = value; }
        }

        /// <summary>
        /// Next Access will be the available access time to API Key for the 
        /// </summary>
        public DateTime NextAccess
        {
            get { return nextAccess; }
            set { nextAccess = value; }
        }

        /// <summary>
        /// It can be ACTIVE or INACTIVE depending onexceeding the limit
        /// </summary>
        public string Status
        {
            get { return status; }
            set { status = value; }
        }

    }
}